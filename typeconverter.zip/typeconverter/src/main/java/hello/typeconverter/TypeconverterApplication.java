package hello.typeconverter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TypeconverterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TypeconverterApplication.class, args);
	}

}
